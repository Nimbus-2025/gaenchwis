import React from 'react';
import { TextField } from '@material-ui/core';

const Datepicker = ({ setDate, date }) => {
  return (
    <TextField
      id="datetime-local"
      label="일정 시간"
      type="datetime-local"
      value={date}
      onChange={(e) => setDate(e.target.value)}
      InputLabelProps={{
        shrink: true,
      }}
    />
  );
};

export default Datepicker; 