import React from 'react';
import Datepicker from './Datepicker';
import { updateSchedule, deleteSchedule, openEditPopup } from '../../src/component/calendar1/redux/modules/schedule';

const EditSchedule = () => {
  return (
    <div>
      <h1>일정 수정</h1>
    </div>
  );
};

export default EditSchedule;