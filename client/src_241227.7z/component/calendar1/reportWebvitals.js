import { getCLS, getFID, getFCP, getLCP, getTTFB } from 'web-vitals';

/**
 * Web Vitals 성능 메트릭을 측정하고 보고하는 함수
 * @param {Function} onPerfEntry - 성능 측정 결과를 처리할 콜백 함수
 * @returns {void}
 */
const reportWebVitals = async (onPerfEntry) => {
  try {
    if (onPerfEntry && typeof onPerfEntry === 'function') {
      // 각 성능 메트릭 측정
      getCLS(onPerfEntry); // Cumulative Layout Shift
      getFID(onPerfEntry); // First Input Delay
      getFCP(onPerfEntry); // First Contentful Paint
      getLCP(onPerfEntry); // Largest Contentful Paint
      getTTFB(onPerfEntry); // Time to First Byte
    }
  } catch (error) {
    console.error('Failed to report web vitals:', error);
  }
};

export default reportWebVitals;