import React, { useMemo, useCallback, memo } from 'react';
import PropTypes from 'prop-types';
import { useDispatch } from 'react-redux';
import styled from 'styled-components';
import { openEditPopup } from './redux/modules/schedule';

const Day = ({ dateInfo, className }) => {
  const { currentSch: schedule, day } = dateInfo;
  const dispatch = useDispatch();

  const openPopup = useCallback((scheduleItem) => {
    dispatch(openEditPopup({ isOpen: true, schedule: scheduleItem }));
  }, [dispatch]);

  const sortedSchedules = useMemo(() => {
    return [...schedule].sort((a, b) => a.time - b.time);
  }, [schedule]);

  const mapToPlan = useMemo(() => {
    return sortedSchedules.map((scheduleItem) => (
      <Plan
        key={scheduleItem.id || `${scheduleItem.date}-${scheduleItem.time}`}
        className={scheduleItem.completed ? 'completed' : ''}
        onClick={() => openPopup(scheduleItem)}
      >
        {scheduleItem.title}
      </Plan>
    ));
  }, [sortedSchedules, openPopup]);

  return (
    <DayWrapper className={className}>
      <span className="title">{day}</span>
      {mapToPlan}
    </DayWrapper>
  );
};

const DayWrapper = styled.div`
  padding-top: 4px;
  height: 12vh;
  display: flex;
  align-items: center;
  width: 100%;
  flex-direction: column;
  flex-wrap: nowrap;
  overflow: hidden;

  &.grayed {
    color: gray;
  }

  &.today > .title {
    color: white;
    background-color: skyblue;
  }

  & > .title {
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 50%;
    width: 30px;
    height: 30px;
  }
`;

const Plan = styled.span`
  text-align: center;
  font-size: 0.8em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  margin: 1px 0;
  height: 20px;
  width: 100%;
  border-radius: 7px;
  background-color: #ff9aa3;
  color: white;
  cursor: pointer;
  
  &.completed {
    background-color: #bfbfbf;
  }
`;

Day.propTypes = {
  dateInfo: PropTypes.shape({
    day: PropTypes.string.isRequired,
    currentSch: PropTypes.arrayOf(
      PropTypes.shape({
        id: PropTypes.string,
        date: PropTypes.string,
        time: PropTypes.string,
        title: PropTypes.string.isRequired,
        completed: PropTypes.bool
      })
    ).isRequired
  }).isRequired,
  className: PropTypes.string
};

export default memo(Day);