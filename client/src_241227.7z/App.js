import React from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import Calendar from './component/calendar1/index.js';  // 전체 경로 지정
import AddSchedule from './component/calendar1/AddSchedule.js';
import EditSchedule from './component/calendar1/EditSchedule.js';

function App() {
  return (
    <Router>
      <div className="App">
        <Switch>
          <Route exact path="/" component={Calendar} />
          <Route path="/add" component={AddSchedule} />
          <Route path="/edit/:id" component={EditSchedule} />
        </Switch>
      </div>
    </Router>
  );
}

export default App;